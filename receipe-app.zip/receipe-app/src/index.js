// Import appropriate functions
import { setFilters } from './filters'
import { createRecipe } from './recipes'
import { renderRecipes } from './views'

// Render all recipes
renderRecipes()

// Recipe creation listener
document.querySelector('#create-recipe').addEventListener('click', (e) => {
    const recipeID = createRecipe()
    location.assign(`/edit.html#${recipeID.id}`)
})

// Search input listener
document.querySelector('#search-text').addEventListener('input', (e) => {
    setFilters({
        searchText: e.target.value
    })
    renderRecipes()
})