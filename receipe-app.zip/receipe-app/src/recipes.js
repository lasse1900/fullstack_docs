// Import appropriate library
import uuidv4 from "uuid/v4";
import moment from "moment";
// Recipes array
let recipes = []

// Fetch recipes function
const fetchRecipes = () => {
    try {
        const dbRecipes = localStorage.getItem('recipes')
        recipes =  dbRecipes ? JSON.parse(dbRecipes) : []
    } catch (e) {
        recipes = []
    }
}

// Fetch recipes
fetchRecipes()
const getRecipes = () => recipes

// Save recipes to localStorage
const saveRecipes = () => {
    localStorage.setItem('recipes', JSON.stringify(recipes))
}

// Create recipe
const createRecipe = () => {
    const newRecipe = {
        id: uuidv4(),
        title: '',
        text: '',
        createdAt: moment().valueOf(),
        updatedAt: moment().valueOf(),
        ingredients: []
    }
    recipes.push(newRecipe)
    saveRecipes()
    return newRecipe
}

// Delete recipe
const removeRecipe = (id) => {
    const recipeIndex = recipes.findIndex((recipe) => recipe.id === id)
    if (recipeIndex > -1) {
        recipes.splice(recipeIndex, 1)
        saveRecipes()
    }
}

// Update recipe
const updateReceipe = (id, { title, text }) => {
    const recipe = recipes.find((recipe) => recipe.id === id)

    if (!recipe) {
        return
    }

    if (typeof title === 'string') {
        recipe.title = title
        recipe.updatedAt = moment().valueOf()
    }

    if (typeof text === 'string') {
        recipe.text = text
        recipe.updatedAt = moment().valueOf()
    }
    saveRecipes()
    return recipe
}

//Export appropriate functions
export { getRecipes, createRecipe, removeRecipe, saveRecipes, updateReceipe, fetchRecipes }