const filters = {
    searchText: ''
}

const setFilters = ({ searchText }) => {
    if (typeof searchText === 'string') {
        filters.searchText = searchText
    }
}

const getFilters = () => filters

export { setFilters, getFilters }