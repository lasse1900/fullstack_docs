// Import appropriate functions
import moment from "moment";
import { getRecipes } from './recipes';
import { getFilters } from './filters';
import { removeIngridient, toggleIngridient } from './ingredients';

// Render recipes function
const renderRecipes =  () => {
    const {searchText} = getFilters()
    const container = document.querySelector('#recipes')
    
    const filteredRecipes = getRecipes().filter((recipe) => {
        return recipe.title.toLowerCase().includes(searchText.toLowerCase())
    })

    if (filteredRecipes.length > 0) {
        container.innerHTML = ''
        filteredRecipes.forEach((recipe) => {
            const recipeElements = generateRecipesDom(recipe)
            $(recipeElements).hide()
            $('#recipes').append(recipeElements).children(':last').fadeIn(300)
            
        })
    } else {
        container.innerHTML = ''
        const emptyMessage = document.createElement('div')
        emptyMessage.innerHTML = '<p>No recipes to show :(</p>'
        emptyMessage.classList.add('empty-message')
        container.appendChild(emptyMessage)
    }
}

// Generate recipes DOM function
const generateRecipesDom = (recipe) => {
    const wrapper           = document.createElement('a')
    const title             = document.createElement('p')
    const body              = document.createElement('p')
    const recipeTextWrapper = document.createElement('div')
    const iconWrapper       = document.createElement('div')

    // Title configuration
    title.classList.add('recipe-title')
    if (recipe.title.length > 0) {
        title.textContent = recipe.title
    } else {
        title.textContent = 'Untitled'
    }

    // Body configuration
    body.classList.add('recipe-body')

    // Check if every ingredient is true
    const every = recipe.ingredients.every((ingredient) => ingredient.exist)
    // Check if one of the ingredients is true
    const some  = recipe.ingredients.some((ingredient => ingredient.exist))

    if (recipe.ingredients.length > 0) {
        if (every) {
            body.textContent = 'You have all the ingredients'
        } else if (some) {
            body.textContent = 'You have some of the ingredients'
        } else {
            body.textContent = 'You have none of the ingredients'
        }
    } else {
        body.textContent = 'You have not ingredients'
    }

    // Text wrapper configurtion
    recipeTextWrapper.appendChild(title)
    recipeTextWrapper.appendChild(body)

    // Pen icon configuration
    iconWrapper.innerHTML = '<svg aria-hidden="true" data-prefix="fas" data-icon="pencil-alt" class="svg-inline--fa fa-pencil-alt fa-w-16" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M497.9 142.1l-46.1 46.1c-4.7 4.7-12.3 4.7-17 0l-111-111c-4.7-4.7-4.7-12.3 0-17l46.1-46.1c18.7-18.7 49.1-18.7 67.9 0l60.1 60.1c18.8 18.7 18.8 49.1 0 67.9zM284.2 99.8L21.6 362.4.4 483.9c-2.9 16.4 11.4 30.6 27.8 27.8l121.5-21.3 262.6-262.6c4.7-4.7 4.7-12.3 0-17l-111-111c-4.8-4.7-12.4-4.7-17.1 0zM124.1 339.9c-5.5-5.5-5.5-14.3 0-19.8l154-154c5.5-5.5 14.3-5.5 19.8 0s5.5 14.3 0 19.8l-154 154c-5.5 5.5-14.3 5.5-19.8 0zM88 424h48v36.3l-64.5 11.3-31.1-31.1L51.7 376H88v48z"></path></svg>'
    iconWrapper.classList.add('icon-wrapper')
    // Main wrapper configuration
    wrapper.setAttribute('href',`/edit.html#${recipe.id}` )
    wrapper.classList.add('recipe')
    wrapper.appendChild(recipeTextWrapper)
    wrapper.appendChild(iconWrapper)

    return wrapper
}

// Render recipe function
const recipeRender = (id) => {
    const IngridientsContainer = document.querySelector('#ingredients')
    const recipeTitle = document.querySelector('#recipe-title')
    const recipeText = document.querySelector('#recipe-body')
    const timeStamp = document.querySelector('#time-stamp')

    const recipe = getRecipes().find((item) => item.id === id)
    
    if (!recipe) {
        location.assign('/index.html')
    }

    recipeTitle.value = recipe.title
    recipeText.value = recipe.text
    timeStamp.textContent = generatelastEdited(recipe.updatedAt)

    IngridientsContainer.innerHTML = ''

    recipe.ingredients.forEach((ingredient) => {
        const recipeDom = generateRecipeDom(id, ingredient)
        $(recipeDom).hide()
        $('#ingredients').append(recipeDom).children(':last').fadeIn(300)
    })
}

// Generate recipe DOM function
const generateRecipeDom = (id, ingredient) => {
    const ingredientWrapper = document.createElement('label')
    const ingredientContainer = document.createElement('div')
    const ingredientInput = document.createElement('input')
    const ingredientTitle = document.createElement('span')
    const ingredientRemoveBtn = document.createElement('button')

    // Checkbox configuration
    ingredientInput.setAttribute('type', 'checkbox')
    ingredientInput.checked = ingredient.exist
    ingredientInput.addEventListener('change', (e) => {
        toggleIngridient(ingredient)
    })
    ingredientContainer.classList.add('ingredients-wrapper__checkbox__span')
    ingredientContainer.appendChild(ingredientInput)

    // Title configuration
    ingredientTitle.textContent = ingredient.title
    ingredientContainer.appendChild(ingredientTitle)

    // Remove button configuration
    ingredientRemoveBtn.innerHTML = '<svg aria-hidden="true" data-prefix="fas" data-icon="trash" class="svg-inline--fa fa-trash fa-w-14" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M0 84V56c0-13.3 10.7-24 24-24h112l9.4-18.7c4-8.2 12.3-13.3 21.4-13.3h114.3c9.1 0 17.4 5.1 21.5 13.3L312 32h112c13.3 0 24 10.7 24 24v28c0 6.6-5.4 12-12 12H12C5.4 96 0 90.6 0 84zm415.2 56.7L394.8 467c-1.6 25.3-22.6 45-47.9 45H101.1c-25.3 0-46.3-19.7-47.9-45L32.8 140.7c-.4-6.9 5.1-12.7 12-12.7h358.5c6.8 0 12.3 5.8 11.9 12.7z"></path></svg>'
    ingredientRemoveBtn.classList.add('btn', 'btn-remove')
    ingredientRemoveBtn.addEventListener('click', (e) => {
        removeIngridient(id, ingredient)
        recipeRender(id)
    })
    
    // Append div to label
    ingredientWrapper.classList.add('ingredients-wrapper')
    ingredientWrapper.appendChild(ingredientContainer)

    // Append remove button to label
    ingredientWrapper.appendChild(ingredientRemoveBtn)

    // Return wrapper
    return ingredientWrapper
}

//Generate last recipe edited
const generatelastEdited = (timestamp) => `Last edited ${moment(timestamp).fromNow()}`

//Scrolling to bottom function
const scrollToBottom = () => {
    const ingredientsContainer = document.querySelector('#ingredients')
    window.scrollTo(0, ingredientsContainer.scrollHeight)
}

//Export appropriate functions
export { renderRecipes, recipeRender, generatelastEdited, scrollToBottom }