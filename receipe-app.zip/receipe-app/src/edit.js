// Appropriate imports
import { recipeRender, generatelastEdited, scrollToBottom } from './views'
import { createIngridient } from './ingredients'
import { updateReceipe, removeRecipe, fetchRecipes } from './recipes'

// Title and text inputs, form selector, delete recipe and save recipe buttons
const recipeTitle    = document.querySelector('#recipe-title')
const recipeText     = document.querySelector('#recipe-body')
const ingredientForm = document.querySelector('#ingredient-form')
const deleteRecipe   = document.querySelector('#remove-recipe')
const saveRecipe     = document.querySelector('#save-recipe')
const timeStamp      = document.querySelector('#time-stamp')

// Recipe id
const recipeId = location.hash.substring(1)

// Render recipe
recipeRender(recipeId)

// Form handling add ingredient
ingredientForm.addEventListener('submit', (e) => {
    const text = e.target.elements.addIngridient.value.trim()
    e.preventDefault()
    const recipe = createIngridient(recipeId, text)
    timeStamp.textContent = generatelastEdited(recipe.updatedAt)
    e.target.elements.addIngridient.value = ''
    recipeRender(recipeId)
    scrollToBottom();
})

// Title update
recipeTitle.addEventListener('input', (e) => {
    const recipe = updateReceipe(recipeId, {
        title: e.target.value
    })
    timeStamp.textContent = generatelastEdited(recipe.updatedAt)
})

// Body update
recipeText.addEventListener('input', (e) => {
   const recipe = updateReceipe(recipeId, {
        text: e.target.value
    })
    timeStamp.textContent = generatelastEdited(recipe.updatedAt)
})

// Delete recipe
deleteRecipe.addEventListener('click', (e) => {
    removeRecipe(recipeId)
    location.assign('/index.html')
})

// Save recipe "Just for UX purposes"
saveRecipe.addEventListener('click', (e) => {
    location.assign('/index.html')
})

// Window event listener
window.addEventListener('storage', (e) => {
    if (e.key === 'recipes') {
        fetchRecipes()
        recipeRender(recipeId)
    }
})