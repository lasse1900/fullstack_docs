// Also because of different OS the __dirname is working differently
// nodeJS give us some functions to fix this issue

const path = require('path') // Built in Nodejs module

module.exports = {
    entry: {
        index: ['babel-polyfill', './src/index.js'],
        edit: ['babel-polyfill', './src/edit.js']
    }, // This require relative path
    output: {
        path: path.resolve(__dirname, 'public/scripts'), // This require ABSOLUTE PATH (*)
        filename: '[name]-bundle.js'
    },
    module: {
        rules: [{
            test: '/\.js$/',
            exclude: '/node_modules/',
            use: {
                loader: 'babel-loader',
                options: {
                    presets: ['env'],
                    plugins: ['transform-object-rest-spread']
                }
            }
        }]
    },
    devServer: {
        contentBase: path.resolve(__dirname, 'public'),
        publicPath: '/scripts/' // <-- Relative to the public folder that serve virtual bundle.js
    },
    devtool: 'source-map'// <-- Show exact line on browser console when we debug 
}

// (*) My Absolute path is this
// Users/dtsiridakis/javaScript/boilerplate/public/scripts
// But if i change the project location or share my code the path is CHANGED!

           // ++++++++++++++++++++++++++++++++++++++++++ //

// To solve this issue nodeJS give us a Global Variable
// __dirname this give us the absolute path of our project! 
